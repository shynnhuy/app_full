package com.mavenstore.mapper;

import com.mavenstore.model.ProductsModel;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductMapper implements RowMapper<ProductsModel> {

    @Override
    public ProductsModel mapRow(ResultSet resultSet) {
        try {
            ProductsModel product = new ProductsModel();
            product.setId(resultSet.getInt("id"));
            product.setIdCategory(resultSet.getInt("idcategory"));
            product.setName(resultSet.getString("name"));
            product.setCode(resultSet.getString("code"));
            product.setColor(resultSet.getString("color"));
            product.setPrice(resultSet.getFloat("price"));
            product.setNew_price(resultSet.getFloat("newprice"));
            product.setDescription(resultSet.getString("description"));
            return product;
        } catch (SQLException e) {
            return null;
        }
    }
}
