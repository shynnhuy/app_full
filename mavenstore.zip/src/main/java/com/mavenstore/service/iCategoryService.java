package com.mavenstore.service;

import com.mavenstore.model.CategoryModel;

import java.util.List;

public interface iCategoryService {
    List<CategoryModel> findAll();
}
