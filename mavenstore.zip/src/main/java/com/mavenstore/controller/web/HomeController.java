package com.mavenstore.controller.web;

import com.mavenstore.DAO.iCategoryDAO;
import com.mavenstore.DAO.impl.CategoryDAO;
import com.mavenstore.service.iCategoryService;
import com.mavenstore.service.iProductService;
import com.mavenstore.service.impl.CategoryService;
import com.mavenstore.service.impl.ProductService;

import javax.inject.Inject;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(
        name = "HomeController",
        urlPatterns = {"/home"}
)
public class HomeController extends HttpServlet {
//    @Inject
//    public iCategoryService iCategoryService;
    private iCategoryService categoryService;
    private iProductService productService;
    public HomeController() {
        categoryService = new CategoryService();
        productService = new ProductService();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        session.setAttribute("LISTCATE", categoryService.findAll());
        session.setAttribute("LISTPRODUCT", productService.findAll());
        RequestDispatcher dispatcher = request.getRequestDispatcher("/views/web/home.jsp");
        dispatcher.forward(request, response);
    }
}
