package com.mavenstore.service;


import com.mavenstore.model.ProductsModel;

import java.util.List;

public interface iProductService {
    List<ProductsModel> findAll();
}
