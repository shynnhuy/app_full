package com.mavenstore.DAO;


import com.mavenstore.model.ProductsModel;

import java.util.List;

public interface iProductDAO extends GenericDAO<ProductsModel> {
    List<ProductsModel> findAll();
}
