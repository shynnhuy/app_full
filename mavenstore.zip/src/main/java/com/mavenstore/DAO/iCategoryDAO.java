package com.mavenstore.DAO;

import com.mavenstore.model.CategoryModel;

import java.util.List;

public interface iCategoryDAO extends GenericDAO {
    List<CategoryModel> findAll();
}
