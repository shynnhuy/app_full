package com.mavenstore.DAO.impl;

import com.mavenstore.DAO.iCategoryDAO;
import com.mavenstore.model.CategoryModel;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryDAO extends AbstractDAO implements iCategoryDAO {
    public Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/mavenstore";
            String user = "root";
            String pass = "";
            return DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException | SQLException e) {
            return null;
        }
    }

    @Override
    public List<CategoryModel> findAll() {
        List<CategoryModel> result = new ArrayList<>();
        String sql = "SELECT * FROM category";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Connection conn = getConnection();
        if (conn != null) {
            try {
                statement = conn.prepareStatement(sql);
                resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    CategoryModel category = new CategoryModel();
                    category.setId(resultSet.getInt("id"));
                    category.setName(resultSet.getString("name"));
                    result.add(category);
                }
                return result;
            } catch (SQLException e) {
                return null;
            } finally {
                try {
                    if (conn != null) {
                        conn.close();
                    }
                    if (statement != null) {
                        statement.close();
                    }
                    if (resultSet != null) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                    return null;
                }
            }
        }
        return null;
    }
}
