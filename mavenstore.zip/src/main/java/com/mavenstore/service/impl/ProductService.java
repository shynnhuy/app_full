package com.mavenstore.service.impl;

import com.mavenstore.DAO.iProductDAO;
import com.mavenstore.DAO.impl.ProductDAO;
import com.mavenstore.model.CategoryModel;
import com.mavenstore.model.ProductsModel;
import com.mavenstore.service.iCategoryService;
import com.mavenstore.service.iProductService;

import java.util.List;

public class ProductService implements iProductService {
    private iProductDAO productDAO;
    public ProductService() {
        productDAO = new ProductDAO();
    }
    @Override
    public List<ProductsModel> findAll() {
        return productDAO.findAll();
    }
}
