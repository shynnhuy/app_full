package com.mavenstore.DAO.impl;

import com.mavenstore.DAO.iProductDAO;
import com.mavenstore.mapper.ProductMapper;
import com.mavenstore.model.ProductsModel;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO extends AbstractDAO<ProductsModel> implements iProductDAO {
    @Override
    public List<ProductsModel> findAll() {
        String sql = "SELECT * FROM product ORDER BY id";
        return query(sql, new ProductMapper());
    }

//    @Override
//    public List<ProductsModel> findAll() {
//        List<ProductsModel> result = new ArrayList<>();
//        String sql = "SELECT * FROM product ORDER BY id";
//        PreparedStatement statement = null;
//        ResultSet resultSet = null;
//        Connection conn = getConnection();
//        if (conn != null) {
//            try {
//                statement = conn.prepareStatement(sql);
//                resultSet = statement.executeQuery();
//                while (resultSet.next()) {
//                    ProductsModel product = new ProductsModel();
//                    product.setId(resultSet.getInt("id"));
//                    product.setIdCategory(resultSet.getInt("idcategory"));
//                    product.setName(resultSet.getString("name"));
//                    product.setCode(resultSet.getString("code"));
//                    product.setColor(resultSet.getString("color"));
//                    product.setPrice(resultSet.getFloat("price"));
//                    product.setNew_price(resultSet.getFloat("newprice"));
//                    product.setDescription(resultSet.getString("description"));
//                    result.add(product);
//                }
//                return result;
//            } catch (SQLException e) {
//                return null;
//            } finally {
//                try {
//                    if (conn != null) {
//                        conn.close();
//                    }
//                    if (statement != null) {
//                        statement.close();
//                    }
//                    if (resultSet != null) {
//                        resultSet.close();
//                    }
//                } catch (SQLException e) {
//                    return null;
//                }
//            }
//        }
//        return null;
//    }
}
