package com.mavenstore.service.impl;

import com.mavenstore.DAO.iCategoryDAO;
import com.mavenstore.DAO.impl.CategoryDAO;
import com.mavenstore.model.CategoryModel;
import com.mavenstore.service.iCategoryService;

import javax.inject.Inject;
import java.util.List;

public class CategoryService implements iCategoryService {
    private iCategoryDAO categoryDAO;
    public CategoryService() {
        categoryDAO = new CategoryDAO();
    }
    @Override
    public List<CategoryModel> findAll() {
        return categoryDAO.findAll();
    }
}
