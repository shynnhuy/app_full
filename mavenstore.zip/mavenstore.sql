/*
 Navicat Premium Data Transfer

 Source Server         : LOCALHOST-XAMPP
 Source Server Type    : MySQL
 Source Server Version : 100406
 Source Host           : localhost:3306
 Source Schema         : mavenstore

 Target Server Type    : MySQL
 Target Server Version : 100406
 File Encoding         : 65001

 Date: 28/11/2019 02:25:42
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fullname` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `roleid` int(11) NOT NULL DEFAULT 1,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `avatar` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `age` int(11) NULL DEFAULT NULL,
  `wallet` float NULL DEFAULT NULL,
  `street` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `city` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `website` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE,
  INDEX `gender`(`gender`) USING BTREE,
  INDEX `role`(`roleid`) USING BTREE,
  INDEX `status`(`status`) USING BTREE,
  CONSTRAINT `gender` FOREIGN KEY (`gender`) REFERENCES `gender` (`idGender`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `role` FOREIGN KEY (`roleid`) REFERENCES `role` (`idRole`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `status` FOREIGN KEY (`status`) REFERENCES `status` (`idStatus`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES (3, 'shynn2', '123', 'Nguyen Xuan Huy2', 'shynn2@mail.vn', 2, 1, 'commons/users/images/932954.jpg', 1, 18, 100, NULL, NULL, NULL);
INSERT INTO `account` VALUES (5, 'test', '123', 'test test huy', 'test@gmail.com', 1, 1, 'commons/users/images/default-avatar.png', 1, 21, 100, NULL, NULL, NULL);
INSERT INTO `account` VALUES (6, 'test1', '123', 'test test1', 'test1@gmail', 1, 1, 'commons/users/images/â™¥.jpg', 2, 23, 121, NULL, NULL, NULL);
INSERT INTO `account` VALUES (7, 'testuser', '123', 'testuser user', 'testuser@gmail.com', 1, 2, 'commons/users/images/932954.jpg', 1, 0, 0, NULL, NULL, NULL);
INSERT INTO `account` VALUES (8, 'shynnhuy', '123', 'Nguyen Xuan Huy', 'shynn@hotmail.com', 3, 1, 'commons/users/images/932954.jpg', 1, 18, 9999, 'Pham Nhu Xuong', 'Da Nang', 'https://fb.com/shynnhuy');

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `idCate` int(11) NOT NULL,
  `nameCate` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `codeCate` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`idCate`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES (0, 'Apple', 'apple');
INSERT INTO `category` VALUES (1, 'Samsung', 'samsung');
INSERT INTO `category` VALUES (2, 'Xiaomi', 'xiaomi');
INSERT INTO `category` VALUES (3, 'Oppo', 'oppo');
INSERT INTO `category` VALUES (4, 'Lenovo', 'lenovo');
INSERT INTO `category` VALUES (5, 'HTC', 'htc');

-- ----------------------------
-- Table structure for gender
-- ----------------------------
DROP TABLE IF EXISTS `gender`;
CREATE TABLE `gender`  (
  `idGender` int(11) NOT NULL AUTO_INCREMENT,
  `nameGender` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`idGender`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of gender
-- ----------------------------
INSERT INTO `gender` VALUES (1, 'Male');
INSERT INTO `gender` VALUES (2, 'Female');
INSERT INTO `gender` VALUES (3, 'Other');

-- ----------------------------
-- Table structure for order_items
-- ----------------------------
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items`  (
  `idItem` int(11) NOT NULL AUTO_INCREMENT,
  `idProduct` int(11) NULL DEFAULT NULL,
  `quantity` int(11) NULL DEFAULT NULL,
  `price` float(10, 2) NULL DEFAULT NULL,
  `idOrder` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`idItem`) USING BTREE,
  INDEX `idproduct`(`idProduct`) USING BTREE,
  INDEX `order`(`idOrder`) USING BTREE,
  CONSTRAINT `idproduct` FOREIGN KEY (`idProduct`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order` FOREIGN KEY (`idOrder`) REFERENCES `orders` (`idOrder`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 48 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of order_items
-- ----------------------------
INSERT INTO `order_items` VALUES (27, 6, 1, 359.00, 17);
INSERT INTO `order_items` VALUES (28, 3, 1, 339.00, 17);
INSERT INTO `order_items` VALUES (29, 6, 1, 359.00, 17);
INSERT INTO `order_items` VALUES (30, 3, 1, 339.00, 17);
INSERT INTO `order_items` VALUES (37, 2, 2, 259.00, 21);
INSERT INTO `order_items` VALUES (38, 4, 1, 219.00, 21);
INSERT INTO `order_items` VALUES (39, 2, 2, 259.00, 22);
INSERT INTO `order_items` VALUES (40, 4, 1, 219.00, 22);
INSERT INTO `order_items` VALUES (41, 1, 3, 239.00, 23);
INSERT INTO `order_items` VALUES (42, 1, 3, 239.00, 24);
INSERT INTO `order_items` VALUES (43, 1, 3, 239.00, 25);
INSERT INTO `order_items` VALUES (44, 1, 3, 239.00, 26);
INSERT INTO `order_items` VALUES (45, 1, 3, 239.00, 27);
INSERT INTO `order_items` VALUES (46, 1, 3, 239.00, 28);
INSERT INTO `order_items` VALUES (47, 3, 1, 339.00, 29);

-- ----------------------------
-- Table structure for order_status
-- ----------------------------
DROP TABLE IF EXISTS `order_status`;
CREATE TABLE `order_status`  (
  `idOrderStatus` int(11) NOT NULL,
  `nameOrderStatus` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`idOrderStatus`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of order_status
-- ----------------------------
INSERT INTO `order_status` VALUES (0, 'Pending');
INSERT INTO `order_status` VALUES (1, 'Processing');
INSERT INTO `order_status` VALUES (2, 'Completed');
INSERT INTO `order_status` VALUES (3, 'Failed');
INSERT INTO `order_status` VALUES (4, 'Cancelled');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `idOrder` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NULL DEFAULT NULL,
  `keyOrder` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `statusOrder` int(11) NULL DEFAULT 0,
  `datecreate` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idOrder`) USING BTREE,
  UNIQUE INDEX `key`(`keyOrder`) USING BTREE,
  INDEX `user`(`idUser`) USING BTREE,
  INDEX `statusOrder`(`statusOrder`) USING BTREE,
  CONSTRAINT `orderstatus` FOREIGN KEY (`statusOrder`) REFERENCES `order_status` (`idOrderStatus`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user` FOREIGN KEY (`idUser`) REFERENCES `account` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 30 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (17, 6, 'wNqXRVbtPk', 0, NULL);
INSERT INTO `orders` VALUES (21, 6, 'RanIUOXrYo', 0, NULL);
INSERT INTO `orders` VALUES (22, 6, 'eAJGvzwPSC', 0, NULL);
INSERT INTO `orders` VALUES (23, 0, 'umOjxniwzr', 0, NULL);
INSERT INTO `orders` VALUES (24, 0, 'FETjDPNiAu', 0, NULL);
INSERT INTO `orders` VALUES (25, 0, 'rsMgBHOGxA', 0, NULL);
INSERT INTO `orders` VALUES (26, 0, 'TMJuaZxnyI', 0, NULL);
INSERT INTO `orders` VALUES (27, 0, 'nIJQMLxHlb', 0, NULL);
INSERT INTO `orders` VALUES (28, 0, 'qmvUgnslbu', 0, NULL);
INSERT INTO `orders` VALUES (29, 6, 'nQabAOKSzN', 0, '2019-05-30 11:37:09');

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(11) NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `price` float(10, 2) NULL DEFAULT NULL,
  `newprice` float(10, 2) NULL DEFAULT NULL,
  `color` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `thumbnail` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `code`(`code`) USING BTREE,
  INDEX `category`(`idcategory`) USING BTREE,
  CONSTRAINT `category` FOREIGN KEY (`idcategory`) REFERENCES `category` (`idCate`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES (1, 0, 'Iphone 5', 'ip5', 250.00, 239.00, 'white', 'White iphone 5 on sale', 'images/ip5.png');
INSERT INTO `product` VALUES (2, 0, 'Iphone 5s', 'ip5s', 280.00, 259.00, 'gold', 'Gold iphone 5s on sale', 'images/ip5s.png');
INSERT INTO `product` VALUES (3, 0, 'Iphone 6', 'ip6', 350.00, 339.00, 'white', 'White iphone 6 on sale', 'images/ip6.png');
INSERT INTO `product` VALUES (4, 1, 'Galaxy s5', 'glxs5', 250.00, 219.00, 'black', 'Black samsung galaxy s5 sale', 'images/glxs5.png');
INSERT INTO `product` VALUES (5, 1, 'Galaxy s7', 'glxs7', 350.00, 329.00, 'black', 'Black samsung galaxy s7', 'images/glxs7.png');
INSERT INTO `product` VALUES (6, 1, 'Galaxy s7 edge', 'glxs7e', 400.00, 359.00, 'gold', 'Gold samsung galaxy s7 edge', 'images/glxs7e.png');
INSERT INTO `product` VALUES (7, 2, 'Mi 6', 'mi6', 400.00, 369.00, 'blue', 'Blue xiaomi mi6 ', NULL);
INSERT INTO `product` VALUES (8, 2, 'Mi 8', 'mi8', 420.00, 409.00, 'black', 'Black xiaomi mi8 ', NULL);
INSERT INTO `product` VALUES (9, 2, 'Mi 9', 'mi9', 520.00, 509.00, 'black', 'Black xiaomi mi9', NULL);
INSERT INTO `product` VALUES (10, 4, 'Test API 1', 'api1', 320.00, 220.00, 'white', 'asdhasbdnlm;asdabsn', NULL);
INSERT INTO `product` VALUES (12, 1, 'Test API 100', 'tapi100', 100.00, 120.00, 'white-pink', 'asdhasbdnlm;asdabsn', 'nonenone');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `idRole` int(255) NOT NULL,
  `nameRole` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`idRole`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, 'Member');
INSERT INTO `role` VALUES (2, 'Moderators');
INSERT INTO `role` VALUES (3, 'Administrator');

-- ----------------------------
-- Table structure for status
-- ----------------------------
DROP TABLE IF EXISTS `status`;
CREATE TABLE `status`  (
  `idStatus` tinyint(4) NOT NULL,
  `nameStatus` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`idStatus`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of status
-- ----------------------------
INSERT INTO `status` VALUES (1, 'whitelist');
INSERT INTO `status` VALUES (2, 'banned');

SET FOREIGN_KEY_CHECKS = 1;
